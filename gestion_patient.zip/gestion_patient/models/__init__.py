# -*- coding: utf-8 -*-

from . import gestion_patient_patients
