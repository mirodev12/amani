{
    'name': "Gestion Patient",
    'version': "1.0",
    'author': "marwan Ben mohamed",
    'category': "Tools",
    'support': "mpsitsupport@mpscompany.net",
    'summary': "Gestion Patient Hopital Mtoroch Gabes",
    'description': "Gestion Patient Hopital Mtoroch Gabes",
    'license':'LGPL-3',
    'data': [
       
        'views/gestion_patient_patients_views.xml',
        'views/gestion_patient_stade_views.xml',
        'views/gestion_patient_tnm_views.xml',
        'views/gestion_patient_dossier_views.xml',
        'views/gestion_patient_consultation_views.xml',
        'data/gestion_patient_sequence.xml',
        'views/menus.xml',
       
    ],
    'demo': [],
    'depends': ['web','resource'],
    'images':[
        'static/description/3.jpg',
        'static/description/1.jpg',
        'static/description/2.jpg',
        'static/description/4.jpg',
        'static/description/5.jpg',
        'static/description/6.jpg',
    ],
    'installable': True,
}
